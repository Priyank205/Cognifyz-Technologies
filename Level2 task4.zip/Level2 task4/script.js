document.addEventListener("DOMContentLoaded", () => {
    const routes = document.querySelectorAll(".route");
    const sections = document.querySelectorAll("section");

    // Handle Client-Side Routing
    routes.forEach(route => {
        route.addEventListener("click", (e) => {
            e.preventDefault();
            const target = route.getAttribute("href").substring(1);

            sections.forEach(section => {
                section.classList.add("hidden");
            });

            document.getElementById(`${target}-section`).classList.remove("hidden");
        });
    });

    // Form Validation and Dynamic Feedback
    const form = document.getElementById("dynamic-form");
    const passwordInput = document.getElementById("password");
    const passwordStrength = document.getElementById("password-strength");
    const feedback = document.getElementById("form-feedback");

    // Password Strength Checker
    passwordInput.addEventListener("input", () => {
        const value = passwordInput.value;

        if (value.length < 6) {
            passwordStrength.textContent = "Password Strength: Weak";
            passwordStrength.style.color = "red";
        } else if (value.length < 10) {
            passwordStrength.textContent = "Password Strength: Moderate";
            passwordStrength.style.color = "orange";
        } else if (/[A-Z]/.test(value) && /\d/.test(value) && /[^A-Za-z0-9]/.test(value)) {
            passwordStrength.textContent = "Password Strength: Strong";
            passwordStrength.style.color = "green";
        } else {
            passwordStrength.textContent = "Password Strength: Medium";
            passwordStrength.style.color = "blue";
        }
    });

    // Handle Form Submission
    form.addEventListener("submit", (e) => {
        e.preventDefault(); // Prevent form from reloading the page

        const name = document.getElementById("name").value.trim();
        const email = document.getElementById("email").value.trim();
        const password = document.getElementById("password").value.trim();
        const country = document.getElementById("country").value;

        if (name && email && password && country) {
            // Display the data dynamically on the page
            feedback.innerHTML = `
                <strong>Thank you for submitting your details:</strong>
                <ul>
                    <li><strong>Name:</strong> ${name}</li>
                    <li><strong>Email:</strong> ${email}</li>
                    <li><strong>Country:</strong> ${country}</li>
                </ul>
            `;
            feedback.style.color = "green";
        } else {
            feedback.textContent = "Please fill out all fields correctly!";
            feedback.style.color = "red";
        }
    });
});
